create definer = root@localhost view v_wechat as
select `bw`.`ID`                            AS `ID`,
       `bw`.`SO_ID`                         AS `SO_ID`,
       `bw`.`BW_UUID`                       AS `BW_UUID`,
       `bw`.`BW_USERNAME`                   AS `BW_USERNAME`,
       `bw`.`BW_NICKNAME`                   AS `BW_NICKNAME`,
       `bw`.`BW_GENDER`                     AS `BW_GENDER`,
       `bw`.`BW_AVATAR`                     AS `BW_AVATAR`,
       `bw`.`BW_LOCATION`                   AS `BW_LOCATION`,
       `bw`.`BW_SOURCE`                     AS `BW_SOURCE`,
       `bw`.`BW_ACCESSTOKEN`                AS `BW_ACCESSTOKEN`,
       `bw`.`BW_EXPIREIN`                   AS `BW_EXPIREIN`,
       `bw`.`BW_OPENID`                     AS `BW_OPENID`,
       `bw`.`BW_REFRESHTOKEN`               AS `BW_REFRESHTOKEN`,
       `bw`.`BW_ENTRYTIME`                  AS `BW_ENTRYTIME`,
       `bw`.`BW_LOGINTIME`                  AS `BW_LOGINTIME`,
       `bw`.`IS_STATUS`                     AS `IS_STATUS`,
       ifnull(`bwr`.`BWR_CLOCKIN_COUNT`, 0) AS `CLOCKIN_COUNT`,
       ifnull(`bwp`.`BWP_NUMBER`, 0)        AS `BWP_NUMBER`
from ((`mawei_clockin`.`bus_wechat` `bw` left join `mawei_clockin`.`bus_wechat_praise` `bwp` on ((`bwp`.`BW_ID` = `bw`.`ID`)))
         left join `mawei_clockin`.`bus_wechat_rank` `bwr` on ((`bwr`.`BW_ID` = `bw`.`ID`)));

-- comment on column v_wechat.SO_ID not supported: 操作员

-- comment on column v_wechat.BW_UUID not supported: UUID

-- comment on column v_wechat.BW_USERNAME not supported: 用户名

-- comment on column v_wechat.BW_NICKNAME not supported: 别名

-- comment on column v_wechat.BW_GENDER not supported: 性别

-- comment on column v_wechat.BW_AVATAR not supported: 头像地址

-- comment on column v_wechat.BW_LOCATION not supported: 位置

-- comment on column v_wechat.BW_SOURCE not supported: 来源

-- comment on column v_wechat.BW_ACCESSTOKEN not supported: accessToken

-- comment on column v_wechat.BW_EXPIREIN not supported: expireIn

-- comment on column v_wechat.BW_OPENID not supported: openId

-- comment on column v_wechat.BW_REFRESHTOKEN not supported: refreshToken

-- comment on column v_wechat.BW_ENTRYTIME not supported: 注册时间

-- comment on column v_wechat.BW_LOGINTIME not supported: 最后登录时间

-- comment on column v_wechat.IS_STATUS not supported: 状态 $SYS_ON_OFF$

