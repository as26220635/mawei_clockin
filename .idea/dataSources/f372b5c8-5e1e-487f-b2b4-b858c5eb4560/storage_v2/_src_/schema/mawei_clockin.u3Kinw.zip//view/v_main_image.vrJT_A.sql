create definer = root@localhost view v_main_image as
select `bmi`.`ID`             AS `ID`,
       `bmi`.`BMI_PARENTID`   AS `BMI_PARENTID`,
       `bmi`.`BMI_NAME`       AS `BMI_NAME`,
       `bmi`.`BMI_HEIGHT`     AS `BMI_HEIGHT`,
       `bmi`.`BMI_TOP`        AS `BMI_TOP`,
       `bmi`.`BMI_AREAHEIGHT` AS `BMI_AREAHEIGHT`,
       `bmi`.`BMI_AREAWIDTH`  AS `BMI_AREAWIDTH`,
       `bmi`.`BMI_REMARKS`    AS `BMI_REMARKS`,
       `bmi`.`BMI_ENTRYTIME`  AS `BMI_ENTRYTIME`,
       `bmi`.`BMI_UPDATETIME` AS `BMI_UPDATETIME`,
       `bmi`.`SO_ID`          AS `SO_ID`,
       `bmi`.`IS_STATUS`      AS `IS_STATUS`,
       `sai`.`SAI_NAME`       AS `SAI_NAME`,
       `sf`.`ID`              AS `SF_ID`
from ((`mawei_clockin`.`bus_main_image` `bmi` left join `mawei_clockin`.`sys_account_info` `sai` on ((convert(`sai`.`SO_ID` using utf8mb4) = `bmi`.`SO_ID`)))
         left join `mawei_clockin`.`sys_file` `sf` on (((`sf`.`SF_TABLE_NAME` = 'BUS_MAIN_IMAGE') and
                                                        (convert(`sf`.`SF_TABLE_ID` using utf8mb4) = `bmi`.`ID`) and
                                                        (`sf`.`ID` = (select max(`sf`.`ID`)
                                                                      from `mawei_clockin`.`sys_file` `sf`
                                                                      where ((`sf`.`SF_TABLE_NAME` = 'BUS_MAIN_IMAGE') and
                                                                             (convert(`sf`.`SF_TABLE_ID` using utf8mb4) = `bmi`.`ID`))
                                                                      group by `sf`.`SF_TABLE_ID`)))));

-- comment on column v_main_image.BMI_PARENTID not supported: 父ID

-- comment on column v_main_image.BMI_NAME not supported: 名称

-- comment on column v_main_image.BMI_HEIGHT not supported: 高度

-- comment on column v_main_image.BMI_TOP not supported: 顶部高度

-- comment on column v_main_image.BMI_AREAHEIGHT not supported: 划分区域高度

-- comment on column v_main_image.BMI_AREAWIDTH not supported: 划分区域宽度

-- comment on column v_main_image.BMI_REMARKS not supported: 备注

-- comment on column v_main_image.BMI_ENTRYTIME not supported: 添加时间

-- comment on column v_main_image.BMI_UPDATETIME not supported: 最后操作时间

-- comment on column v_main_image.SO_ID not supported: 最后操作员 @SYS_ACCOUNT_INFO,SO_ID,SAI_NAME@

-- comment on column v_main_image.IS_STATUS not supported: 状态 $SYS_ON_OFF$

-- comment on column v_main_image.SAI_NAME not supported: 账号名称

