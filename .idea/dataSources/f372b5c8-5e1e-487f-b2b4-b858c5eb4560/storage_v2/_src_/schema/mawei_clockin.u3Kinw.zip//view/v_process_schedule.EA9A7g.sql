create definer = root@localhost view v_process_schedule as
select `sps`.`ID`                         AS `ID`,
       `sps`.`SO_ID`                      AS `SO_ID`,
       `sps`.`SHOW_SO_ID`                 AS `SHOW_SO_ID`,
       `sps`.`SPD_ID`                     AS `SPD_ID`,
       `sps`.`SPS_ID`                     AS `SPS_ID`,
       `sps`.`SPS_TABLE_ID`               AS `SPS_TABLE_ID`,
       `sps`.`SPS_TABLE_NAME`             AS `SPS_TABLE_NAME`,
       `sps`.`SPS_AUDIT_STATUS`           AS `SPS_AUDIT_STATUS`,
       `sps`.`SPS_BACK_STATUS`            AS `SPS_BACK_STATUS`,
       `sps`.`SPS_BACK_STATUS_TRANSACTOR` AS `SPS_BACK_STATUS_TRANSACTOR`,
       `sps`.`SPS_STEP_TYPE`              AS `SPS_STEP_TYPE`,
       `sps`.`SPS_STEP_TRANSACTOR`        AS `SPS_STEP_TRANSACTOR`,
       `sps`.`SPS_PREV_AUDIT_STATUS`      AS `SPS_PREV_AUDIT_STATUS`,
       `sps`.`SPS_PREV_STEP_TYPE`         AS `SPS_PREV_STEP_TYPE`,
       `sps`.`SPS_PREV_STEP_TRANSACTOR`   AS `SPS_PREV_STEP_TRANSACTOR`,
       `sps`.`SPS_PREV_STEP_ID`           AS `SPS_PREV_STEP_ID`,
       `sps`.`SPS_IS_CANCEL`              AS `SPS_IS_CANCEL`,
       `spd`.`SPD_NAME`                   AS `SPD_NAME`,
       `sai`.`SAI_NAME`                   AS `INITIATOR_NAME`,
       `saic`.`SAI_NAME`                  AS `CANCEL_NAME`,
       `spsc`.`ID`                        AS `SPSC_ID`,
       `spsc`.`SPSC_REASON`               AS `SPSC_REASON`,
       `spsc`.`SPSC_ENTRY_TIME`           AS `SPSC_ENTRY_TIME`,
       `sdi`.`SDI_NAME`                   AS `PROCESS_STATUS_NAME`,
       `spt`.`SPS_NAME`                   AS `STEP_NAME`
from ((((((`mawei_clockin`.`sys_process_schedule` `sps` left join `mawei_clockin`.`sys_process_step` `spt` on ((`spt`.`ID` = `sps`.`SPS_ID`))) left join `mawei_clockin`.`sys_process_definition` `spd` on ((`spd`.`ID` = `sps`.`SPD_ID`))) left join `mawei_clockin`.`sys_process_schedule_cancel` `spsc` on ((`spsc`.`SPS_ID` = convert(`sps`.`ID` using utf8mb4)))) left join `mawei_clockin`.`sys_account_info` `sai` on ((`sai`.`SO_ID` = `sps`.`SO_ID`))) left join `mawei_clockin`.`sys_account_info` `saic` on ((convert(`saic`.`SO_ID` using utf8mb4) = `spsc`.`SO_ID`)))
         left join `mawei_clockin`.`sys_dict_info` `sdi`
                   on (((`sdi`.`SDT_CODE` = 'SYS_PROCESS_STATUS') and (`sdi`.`SDI_CODE` = `sps`.`SPS_AUDIT_STATUS`))));

-- comment on column v_process_schedule.SO_ID not supported: 创建人ID

-- comment on column v_process_schedule.SHOW_SO_ID not supported: 拥有查看权限的ID

-- comment on column v_process_schedule.SPD_ID not supported: 流程定义ID

-- comment on column v_process_schedule.SPS_ID not supported: 当前办理步骤ID

-- comment on column v_process_schedule.SPS_TABLE_ID not supported: 流程表ID

-- comment on column v_process_schedule.SPS_TABLE_NAME not supported: 流程表名称

-- comment on column v_process_schedule.SPS_AUDIT_STATUS not supported: 审核状态

-- comment on column v_process_schedule.SPS_BACK_STATUS not supported: 退回状态

-- comment on column v_process_schedule.SPS_BACK_STATUS_TRANSACTOR not supported: 退回到的审核状态

-- comment on column v_process_schedule.SPS_STEP_TYPE not supported: 当前办理步骤类型

-- comment on column v_process_schedule.SPS_STEP_TRANSACTOR not supported: 当前办理步骤办理人

-- comment on column v_process_schedule.SPS_PREV_AUDIT_STATUS not supported: 上一次流程审核状态

-- comment on column v_process_schedule.SPS_PREV_STEP_TYPE not supported: 上一次办理步骤类型

-- comment on column v_process_schedule.SPS_PREV_STEP_TRANSACTOR not supported: 上一次办理步骤办理人

-- comment on column v_process_schedule.SPS_PREV_STEP_ID not supported: 上一次办理步骤ID

-- comment on column v_process_schedule.SPS_IS_CANCEL not supported: 是否作废

-- comment on column v_process_schedule.SPD_NAME not supported: 流程名称

-- comment on column v_process_schedule.INITIATOR_NAME not supported: 账号名称

-- comment on column v_process_schedule.CANCEL_NAME not supported: 账号名称

-- comment on column v_process_schedule.SPSC_REASON not supported: 作废原因

-- comment on column v_process_schedule.SPSC_ENTRY_TIME not supported: 作废时间

-- comment on column v_process_schedule.PROCESS_STATUS_NAME not supported: 字典名称

-- comment on column v_process_schedule.STEP_NAME not supported: 步骤名称

