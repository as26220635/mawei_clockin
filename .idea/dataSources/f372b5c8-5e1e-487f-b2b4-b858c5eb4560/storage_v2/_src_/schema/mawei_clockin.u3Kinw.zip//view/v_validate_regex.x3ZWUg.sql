create definer = root@localhost view v_validate_regex as
select `svr`.`ID`                AS `ID`,
       `svr`.`SVR_NAME`          AS `SVR_NAME`,
       `svr`.`SVR_REGEX`         AS `SVR_REGEX`,
       `svr`.`SVR_REGEX_MESSAGE` AS `SVR_REGEX_MESSAGE`,
       `svr`.`IS_STATUS`         AS `IS_STATUS`
from `mawei_clockin`.`sys_validate_regex` `svr`;

-- comment on column v_validate_regex.SVR_REGEX not supported: 正则表达式

-- comment on column v_validate_regex.SVR_REGEX_MESSAGE not supported: 正则错误提示

