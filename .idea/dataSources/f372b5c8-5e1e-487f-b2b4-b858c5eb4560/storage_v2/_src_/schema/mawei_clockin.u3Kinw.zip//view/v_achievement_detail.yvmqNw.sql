create definer = root@localhost view v_achievement_detail as
select `bad`.`ID`            AS `ID`,
       `bad`.`BA_ID`         AS `BA_ID`,
       `bad`.`BW_ID`         AS `BW_ID`,
       `bad`.`BAD_ADDRESS`   AS `BAD_ADDRESS`,
       `bad`.`BAD_REMARKS`   AS `BAD_REMARKS`,
       `bad`.`BAD_FILETYPE`  AS `BAD_FILETYPE`,
       `bad`.`BAD_ENTERTIME` AS `BAD_ENTERTIME`,
       `ba`.`BA_NAME`        AS `BA_NAME`,
       `bw`.`BW_USERNAME`    AS `BW_USERNAME`
from ((`mawei_clockin`.`bus_achievement_detail` `bad` join `mawei_clockin`.`bus_achievement` `ba` on ((`ba`.`ID` = `bad`.`BA_ID`)))
         join `mawei_clockin`.`bus_wechat` `bw` on ((`bw`.`ID` = `bad`.`BW_ID`)));

-- comment on column v_achievement_detail.BW_ID not supported: 微信用户

-- comment on column v_achievement_detail.BAD_ADDRESS not supported: 打卡地点

-- comment on column v_achievement_detail.BAD_REMARKS not supported: 概述

-- comment on column v_achievement_detail.BAD_FILETYPE not supported: 上传文件类型

-- comment on column v_achievement_detail.BAD_ENTERTIME not supported: 录入时间

-- comment on column v_achievement_detail.BA_NAME not supported: 成就名称

-- comment on column v_achievement_detail.BW_USERNAME not supported: 用户名

