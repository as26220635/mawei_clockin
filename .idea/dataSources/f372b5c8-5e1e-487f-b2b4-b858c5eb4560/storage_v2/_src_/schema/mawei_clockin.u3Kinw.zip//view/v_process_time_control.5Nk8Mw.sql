create definer = root@localhost view v_process_time_control as
select `sptc`.`ID`              AS `ID`,
       `sptc`.`SPD_ID`          AS `SPD_ID`,
       `sptc`.`SPTC_START_TIME` AS `SPTC_START_TIME`,
       `sptc`.`SPTC_END_TIME`   AS `SPTC_END_TIME`,
       `sptc`.`SPTC_ENTRY_TIME` AS `SPTC_ENTRY_TIME`,
       `sptc`.`IS_STATUS`       AS `IS_STATUS`
from `mawei_clockin`.`sys_process_time_control` `sptc`;

-- comment on column v_process_time_control.SPD_ID not supported: 流程定义ID

-- comment on column v_process_time_control.SPTC_START_TIME not supported: 开始时间

-- comment on column v_process_time_control.SPTC_END_TIME not supported: 结束时间

-- comment on column v_process_time_control.SPTC_ENTRY_TIME not supported: 录入时间

-- comment on column v_process_time_control.IS_STATUS not supported: 是否启用$SYS_YES_NO$

