create definer = root@localhost view v_configure_column as
select `scc`.`ID`               AS `ID`,
       `scc`.`SC_ID`            AS `SC_ID`,
       `scc`.`SCC_NAME`         AS `SCC_NAME`,
       `scc`.`SCC_FIELD`        AS `SCC_FIELD`,
       `scc`.`SCC_ALIGN`        AS `SCC_ALIGN`,
       `scc`.`SCC_WIDTH`        AS `SCC_WIDTH`,
       `scc`.`SCC_SDT_CODE`     AS `SCC_SDT_CODE`,
       `scc`.`SCC_IS_OPERATION` AS `SCC_IS_OPERATION`,
       `scc`.`SCC_IS_VISIBLE`   AS `SCC_IS_VISIBLE`,
       `scc`.`SCC_IS_STATUS`    AS `SCC_IS_STATUS`,
       `scc`.`SCC_ORDER`        AS `SCC_ORDER`,
       `scc`.`SCC_IS_FIXED`     AS `SCC_IS_FIXED`,
       `scc`.`SCC_IS_EXPORT`    AS `SCC_IS_EXPORT`
from `mawei_clockin`.`sys_configure_column` `scc`;

-- comment on column v_configure_column.SCC_NAME not supported: 列名

-- comment on column v_configure_column.SCC_FIELD not supported: 数据查询字段

-- comment on column v_configure_column.SCC_ALIGN not supported: 对齐方式

-- comment on column v_configure_column.SCC_WIDTH not supported: 宽度

-- comment on column v_configure_column.SCC_SDT_CODE not supported: 字典SDT_CODE

-- comment on column v_configure_column.SCC_IS_OPERATION not supported: 是否是操作列

-- comment on column v_configure_column.SCC_IS_VISIBLE not supported: 是否隐藏

-- comment on column v_configure_column.SCC_IS_STATUS not supported: 是否是状态列

-- comment on column v_configure_column.SCC_ORDER not supported: 排序

-- comment on column v_configure_column.SCC_IS_FIXED not supported: 是否是固定列 $SYS_FIXED$

-- comment on column v_configure_column.SCC_IS_EXPORT not supported: 是否导出 $SYS_YES_NO$

