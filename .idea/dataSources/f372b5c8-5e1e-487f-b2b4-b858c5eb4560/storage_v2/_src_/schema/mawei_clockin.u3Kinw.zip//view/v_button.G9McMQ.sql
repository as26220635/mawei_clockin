create definer = root@localhost view v_button as
select `sb`.`ID`          AS `ID`,
       `sb`.`SB_NAME`     AS `SB_NAME`,
       `sb`.`SB_BUTTONID` AS `SB_BUTTONID`,
       `sb`.`SB_ICON`     AS `SB_ICON`,
       `sb`.`SB_CODE`     AS `SB_CODE`,
       `sb`.`SB_ORDER`    AS `SB_ORDER`,
       `sb`.`SB_TYPE`     AS `SB_TYPE`,
       `sdi`.`SDI_NAME`   AS `SB_TYPE_NAME`
from (`mawei_clockin`.`sys_button` `sb`
         left join `mawei_clockin`.`sys_dict_info` `sdi`
                   on (((`sdi`.`SDT_CODE` = 'SYS_BUTTON_TYPE') and (`sdi`.`SDI_CODE` = `sb`.`SB_TYPE`))));

-- comment on column v_button.SB_NAME not supported: 按钮名称

-- comment on column v_button.SB_BUTTONID not supported: 按钮ID

-- comment on column v_button.SB_ICON not supported: 按钮图标图片

-- comment on column v_button.SB_CODE not supported: 权限编码

-- comment on column v_button.SB_ORDER not supported: 排序

-- comment on column v_button.SB_TYPE not supported: 按钮类型 $SYS_BUTTON_TYPE$

-- comment on column v_button.SB_TYPE_NAME not supported: 字典名称

