create definer = root@localhost view v_validate as
select `sv`.`ID` AS `ID`, `sv`.`SV_TABLE` AS `SV_TABLE`, `sv`.`IS_STATUS` AS `IS_STATUS`
from `mawei_clockin`.`sys_validate` `sv`;

-- comment on column v_validate.SV_TABLE not supported: 表名

