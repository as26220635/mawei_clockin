create definer = root@localhost view v_menu as
select `sm`.`ID`           AS `ID`,
       `sm`.`SC_ID`        AS `SC_ID`,
       `sm`.`SM_NAME`      AS `SM_NAME`,
       `sm`.`SM_PARENTID`  AS `SM_PARENTID`,
       `sm`.`SM_CODE`      AS `SM_CODE`,
       `sm`.`SM_URL`       AS `SM_URL`,
       `sm`.`SM_CLASSICON` AS `SM_CLASSICON`,
       `sm`.`SM_IS_LEAF`   AS `SM_IS_LEAF`,
       `sm`.`SM_IS_EXPAND` AS `SM_IS_EXPAND`,
       `sm`.`SM_TYPE`      AS `SM_TYPE`,
       `sm`.`SM_ORDER`     AS `SM_ORDER`,
       `sm`.`IS_STATUS`    AS `IS_STATUS`,
       `sc`.`SC_NAME`      AS `SC_NAME`
from (`mawei_clockin`.`sys_menu` `sm`
         left join `mawei_clockin`.`sys_configure` `sc` on ((`sc`.`ID` = `sm`.`SC_ID`)));

-- comment on column v_menu.SC_ID not supported: 配置列表ID

-- comment on column v_menu.SM_NAME not supported: 权限名称

-- comment on column v_menu.SM_PARENTID not supported: 父权限ID

-- comment on column v_menu.SM_CODE not supported: 权限编码

-- comment on column v_menu.SM_URL not supported: 访问URL

-- comment on column v_menu.SM_CLASSICON not supported: icon图片class

-- comment on column v_menu.SM_IS_LEAF not supported: 是否是叶节点

-- comment on column v_menu.SM_IS_EXPAND not supported: 是否默认张开节点

-- comment on column v_menu.SM_TYPE not supported: 用户类型:1管理员 2会员

-- comment on column v_menu.SM_ORDER not supported: 排序号

-- comment on column v_menu.IS_STATUS not supported: 状态:0停用1启用

-- comment on column v_menu.SC_NAME not supported: 配置列表名称

