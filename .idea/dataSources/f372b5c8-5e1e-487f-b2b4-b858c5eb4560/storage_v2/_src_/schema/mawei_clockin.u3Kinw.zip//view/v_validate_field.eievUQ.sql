create definer = root@localhost view v_validate_field as
select `svf`.`ID`              AS `ID`,
       `svf`.`SV_ID`           AS `SV_ID`,
       `svf`.`SVF_NAME`        AS `SVF_NAME`,
       `svf`.`SVF_FIELD`       AS `SVF_FIELD`,
       `svf`.`SVF_IS_REQUIRED` AS `SVF_IS_REQUIRED`,
       `svf`.`SVF_MIN_LENGTH`  AS `SVF_MIN_LENGTH`,
       `svf`.`SVF_MAX_LENGTH`  AS `SVF_MAX_LENGTH`,
       `svf`.`SVR_ID`          AS `SVR_ID`,
       `svf`.`IS_STATUS`       AS `IS_STATUS`,
       `svr`.`SVR_NAME`        AS `SVR_NAME`,
       `svg`.`SVG_GROUPS`      AS `SVG_GROUPS`
from ((`mawei_clockin`.`sys_validate_field` `svf` left join `mawei_clockin`.`sys_validate_regex` `svr` on ((`svr`.`ID` = `svf`.`SVR_ID`)))
         left join (select `svgf`.`SVF_ID`                                                                       AS `SVF_ID`,
                           group_concat(`svg`.`SVG_GROUP` order by cast(`svg`.`ID` as signed) ASC separator
                                        ',')                                                                     AS `SVG_GROUPS`
                    from (`mawei_clockin`.`sys_validate_group` `svg`
                             join `mawei_clockin`.`sys_validate_group_field` `svgf` on ((`svgf`.`SVG_ID` = `svg`.`ID`)))
                    group by `svg`.`SV_ID`, `svgf`.`SVF_ID`
                    order by cast(`svg`.`ID` as signed)) `svg` on ((`svf`.`ID` = `svg`.`SVF_ID`)));

-- comment on column v_validate_field.SVF_NAME not supported: 字段名称

-- comment on column v_validate_field.SVF_FIELD not supported: 查询字段

-- comment on column v_validate_field.SVF_IS_REQUIRED not supported: 是否必填

-- comment on column v_validate_field.SVF_MIN_LENGTH not supported: 最小字数

-- comment on column v_validate_field.SVF_MAX_LENGTH not supported: 最大字数

-- comment on column v_validate_field.SVR_ID not supported: 正则表ID

-- comment on column v_validate_field.IS_STATUS not supported: 是否启用

