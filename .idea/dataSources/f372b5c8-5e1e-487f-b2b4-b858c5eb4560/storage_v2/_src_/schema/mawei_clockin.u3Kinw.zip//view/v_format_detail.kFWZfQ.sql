create definer = root@localhost view v_format_detail as
select `sfd`.`ID`            AS `ID`,
       `sfd`.`SF_ID`         AS `SF_ID`,
       `sfd`.`SM_ID`         AS `SM_ID`,
       `sfd`.`SFD_PARENT_ID` AS `SFD_PARENT_ID`,
       `sfd`.`SFD_NAME`      AS `SFD_NAME`,
       `sfd`.`SFD_ORDER`     AS `SFD_ORDER`,
       `sfd`.`IS_STATUS`     AS `IS_STATUS`,
       `sm`.`SM_NAME`        AS `SM_NAME`
from (`mawei_clockin`.`sys_format_detail` `sfd`
         left join `mawei_clockin`.`sys_menu` `sm` on ((convert(`sm`.`ID` using utf8mb4) = `sfd`.`SM_ID`)));

-- comment on column v_format_detail.SF_ID not supported: 格式表ID

-- comment on column v_format_detail.SM_ID not supported: 菜单表ID

-- comment on column v_format_detail.SFD_PARENT_ID not supported: 父类菜单

-- comment on column v_format_detail.SFD_NAME not supported: 名称

-- comment on column v_format_detail.SFD_ORDER not supported: 排序

-- comment on column v_format_detail.IS_STATUS not supported: 状态

-- comment on column v_format_detail.SM_NAME not supported: 权限名称

