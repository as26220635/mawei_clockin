create definer = root@localhost view v_validate_group as
select `svg`.`ID` AS `ID`, `svg`.`SV_ID` AS `SV_ID`, `svg`.`SVG_GROUP` AS `SVG_GROUP`, `svgf`.`SVF_NAMES` AS `SVF_NAMES`
from (`mawei_clockin`.`sys_validate_group` `svg`
         left join (select `svgf`.`SVG_ID` AS `SVG_ID`, group_concat(`svf`.`SVF_NAME` separator ',') AS `SVF_NAMES`
                    from (`mawei_clockin`.`sys_validate_group_field` `svgf`
                             join `mawei_clockin`.`sys_validate_field` `svf` on ((`svf`.`ID` = `svgf`.`SVF_ID`)))
                    group by `svgf`.`SVG_ID`) `svgf` on ((`svgf`.`SVG_ID` = `svg`.`ID`)));

-- comment on column v_validate_group.SVG_GROUP not supported: 组名称

