create definer = root@localhost view v_role as
select `sr`.`ID`         AS `ID`,
       `sr`.`SR_TYPE`    AS `SR_TYPE`,
       `sr`.`SR_CODE`    AS `SR_CODE`,
       `sr`.`SR_NAME`    AS `SR_NAME`,
       `sr`.`SR_EXPLAIN` AS `SR_EXPLAIN`,
       `sr`.`SR_REMARK`  AS `SR_REMARK`,
       `sr`.`IS_STATUS`  AS `IS_STATUS`
from `mawei_clockin`.`sys_role` `sr`;

-- comment on column v_role.SR_TYPE not supported: 用户类型:1管理员 2部门3系部4学生

-- comment on column v_role.SR_CODE not supported: 角色编码

-- comment on column v_role.SR_NAME not supported: 角色名

-- comment on column v_role.SR_EXPLAIN not supported: 角色说明

-- comment on column v_role.SR_REMARK not supported: 角色备注

-- comment on column v_role.IS_STATUS not supported: 状态:0停用1启用

