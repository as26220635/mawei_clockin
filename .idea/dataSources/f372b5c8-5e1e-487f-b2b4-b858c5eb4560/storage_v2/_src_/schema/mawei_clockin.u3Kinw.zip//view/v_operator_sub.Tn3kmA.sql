create definer = root@localhost view v_operator_sub as
select `sos`.`ID`             AS `ID`,
       `sos`.`SO_ID`          AS `SO_ID`,
       `sos`.`SOS_USERNAME`   AS `SOS_USERNAME`,
       `sos`.`SOS_CREATETIME` AS `SOS_CREATETIME`,
       `sos`.`SOS_REMARK`     AS `SOS_REMARK`,
       `sos`.`SOS_DEFAULT`    AS `SOS_DEFAULT`,
       `sos`.`IS_STATUS`      AS `IS_STATUS`
from `mawei_clockin`.`sys_operator_sub` `sos`;

-- comment on column v_operator_sub.SO_ID not supported: 操作员 @SYS_ACCOUNT_INFO,SO_ID,SAI_NAME@

-- comment on column v_operator_sub.SOS_USERNAME not supported: 登录账号

-- comment on column v_operator_sub.SOS_CREATETIME not supported: 录入时间

-- comment on column v_operator_sub.SOS_REMARK not supported: 备注

-- comment on column v_operator_sub.SOS_DEFAULT not supported: 是否默认账户 $SYS_YES_NO$

-- comment on column v_operator_sub.IS_STATUS not supported: 状态  $SYS_ON_OFF$

