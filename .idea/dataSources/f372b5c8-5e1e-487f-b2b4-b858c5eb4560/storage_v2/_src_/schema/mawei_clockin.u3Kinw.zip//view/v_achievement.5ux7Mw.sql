create definer = root@localhost view v_achievement as
select `ba`.`ID`           AS `ID`,
       `ba`.`BA_NAME`      AS `BA_NAME`,
       `ba`.`BA_LONGITUDE` AS `BA_LONGITUDE`,
       `ba`.`BA_LATITUDE`  AS `BA_LATITUDE`,
       `ba`.`BA_ENTRYTIME` AS `BA_ENTRYTIME`,
       `ba`.`BA_RANGE`     AS `BA_RANGE`,
       `ba`.`BA_POINT`     AS `BA_POINT`,
       `ba`.`SO_ID`        AS `SO_ID`,
       `ba`.`IS_STATUS`    AS `IS_STATUS`,
       `sai`.`SAI_NAME`    AS `SAI_NAME`,
       `sf`.`ID`           AS `SF_ID`
from ((`mawei_clockin`.`bus_achievement` `ba` left join `mawei_clockin`.`sys_account_info` `sai` on ((convert(`sai`.`SO_ID` using utf8mb4) = `ba`.`SO_ID`)))
         left join `mawei_clockin`.`sys_file` `sf` on (((`sf`.`SF_TABLE_NAME` = 'BUS_ACHIEVEMENT') and
                                                        (convert(`sf`.`SF_TABLE_ID` using utf8mb4) = `ba`.`ID`) and
                                                        (`sf`.`SF_SDI_CODE` = 2))));

-- comment on column v_achievement.BA_NAME not supported: 成就名称

-- comment on column v_achievement.BA_LONGITUDE not supported: 经度

-- comment on column v_achievement.BA_LATITUDE not supported: 纬度

-- comment on column v_achievement.BA_ENTRYTIME not supported: 录入时间

-- comment on column v_achievement.BA_RANGE not supported: 范围

-- comment on column v_achievement.BA_POINT not supported: 对应主页图片的点

-- comment on column v_achievement.SO_ID not supported: 操作员

-- comment on column v_achievement.IS_STATUS not supported: 状态 $SYS_ON_OFF$

-- comment on column v_achievement.SAI_NAME not supported: 账号名称

