create definer = root@localhost view v_dict_info as
select `sdi`.`ID`            AS `ID`,
       `sdi`.`SDT_ID`        AS `SDT_ID`,
       `sdi`.`SDT_CODE`      AS `SDT_CODE`,
       `sdi`.`SDI_NAME`      AS `SDI_NAME`,
       `sdi`.`SDI_CODE`      AS `SDI_CODE`,
       `sdi`.`SDI_INNERCODE` AS `SDI_INNERCODE`,
       `sdi`.`SDI_PARENTID`  AS `SDI_PARENTID`,
       `sdi`.`SDI_IS_LEAF`   AS `SDI_IS_LEAF`,
       `sdi`.`SDI_REMARK`    AS `SDI_REMARK`,
       `sdi`.`SDI_REQUIRED`  AS `SDI_REQUIRED`,
       `sdi`.`SDI_ORDER`     AS `SDI_ORDER`,
       `sdi`.`IS_STATUS`     AS `IS_STATUS`
from `mawei_clockin`.`sys_dict_info` `sdi`;

-- comment on column v_dict_info.SDT_ID not supported: 字典主表ID

-- comment on column v_dict_info.SDI_NAME not supported: 字典名称

-- comment on column v_dict_info.SDI_INNERCODE not supported: 连接代码

-- comment on column v_dict_info.SDI_PARENTID not supported: 父ID

-- comment on column v_dict_info.SDI_IS_LEAF not supported: 是否是叶节点 $SYS_YES_NO$

-- comment on column v_dict_info.SDI_REQUIRED not supported: 是否必填

-- comment on column v_dict_info.SDI_ORDER not supported: 字典排序

-- comment on column v_dict_info.IS_STATUS not supported: 状态:0停用1启用

