create definer = root@localhost view v_process_step as
select `sps`.`ID`                     AS `ID`,
       `sps`.`SPD_ID`                 AS `SPD_ID`,
       `sps`.`SR_ID`                  AS `SR_ID`,
       `sps`.`SPS_NAME`               AS `SPS_NAME`,
       `sps`.`SPS_ORDER`              AS `SPS_ORDER`,
       `sps`.`SPS_STEP_TYPE`          AS `SPS_STEP_TYPE`,
       `sps`.`SPS_PROCESS_STATUS`     AS `SPS_PROCESS_STATUS`,
       `sps`.`SPS_IS_OVER_TIME`       AS `SPS_IS_OVER_TIME`,
       `sps`.`SPS_OVER_TIME`          AS `SPS_OVER_TIME`,
       `sps`.`SPS_TAB`                AS `SPS_TAB`,
       `sps`.`SPS_IS_ADVANCE_CHECK`   AS `SPS_IS_ADVANCE_CHECK`,
       `sps`.`SPS_IS_RETREAT_CHECK`   AS `SPS_IS_RETREAT_CHECK`,
       `sps`.`SPS_IS_ADVANCE_EXECUTE` AS `SPS_IS_ADVANCE_EXECUTE`,
       `sps`.`SPS_IS_RETREAT_EXECUTE` AS `SPS_IS_RETREAT_EXECUTE`,
       `sr`.`SR_NAME`                 AS `SR_NAME`
from (`mawei_clockin`.`sys_process_step` `sps`
         left join `mawei_clockin`.`sys_role` `sr` on ((`sr`.`ID` = `sps`.`SR_ID`)));

-- comment on column v_process_step.SPD_ID not supported: 流程定义表ID

-- comment on column v_process_step.SR_ID not supported: 所属办理角色

-- comment on column v_process_step.SPS_NAME not supported: 步骤名称

-- comment on column v_process_step.SPS_ORDER not supported: 步骤顺序

-- comment on column v_process_step.SPS_STEP_TYPE not supported: 办理步骤类型

-- comment on column v_process_step.SPS_PROCESS_STATUS not supported: 步骤流程状态

-- comment on column v_process_step.SPS_IS_OVER_TIME not supported: 是否验证超时(开启后不填超时时间，默认为24小时 1440分钟)

-- comment on column v_process_step.SPS_OVER_TIME not supported: 超时时间(分)

-- comment on column v_process_step.SPS_TAB not supported: 步骤标记

-- comment on column v_process_step.SPS_IS_ADVANCE_CHECK not supported: 是否前进校验

-- comment on column v_process_step.SPS_IS_RETREAT_CHECK not supported: 是否退回校验

-- comment on column v_process_step.SPS_IS_ADVANCE_EXECUTE not supported: 是否前进执行

-- comment on column v_process_step.SPS_IS_RETREAT_EXECUTE not supported: 是否退回执行

-- comment on column v_process_step.SR_NAME not supported: 角色名

