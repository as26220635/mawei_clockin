create definer = root@localhost view v_configure as
select `sc`.`ID` AS `ID`, `sc`.`SC_NAME` AS `SC_NAME`, `sc`.`SC_JSP` AS `SC_JSP`, `sc`.`SC_VIEW` AS `SC_VIEW`
from `mawei_clockin`.`sys_configure` `sc`;

-- comment on column v_configure.SC_NAME not supported: 配置列表名称

-- comment on column v_configure.SC_JSP not supported: JSP地址

-- comment on column v_configure.SC_VIEW not supported: 视图名

