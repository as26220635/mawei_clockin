create definer = root@localhost view v_configure_file as
select `scf`.`ID`             AS `ID`,
       `scf`.`SC_ID`          AS `SC_ID`,
       `scf`.`SCF_NAME`       AS `SCF_NAME`,
       `scf`.`IS_STATUS`      AS `IS_STATUS`,
       `scf`.`SCF_ENTRY_TIME` AS `SCF_ENTRY_TIME`,
       `sc`.`SC_NAME`         AS `SC_NAME`
from (`mawei_clockin`.`sys_configure_file` `scf`
         join `mawei_clockin`.`sys_configure` `sc` on ((convert(`sc`.`ID` using utf8mb4) = `scf`.`SC_ID`)));

-- comment on column v_configure_file.ID not supported: 主键

-- comment on column v_configure_file.SC_ID not supported: 配置列表 @SYS_CONFIGURE,SC_NAME@

-- comment on column v_configure_file.SCF_NAME not supported: 文件名称

-- comment on column v_configure_file.IS_STATUS not supported: 是否启用 $SYS_YES_NO$

-- comment on column v_configure_file.SCF_ENTRY_TIME not supported: 录入时间

-- comment on column v_configure_file.SC_NAME not supported: 配置列表名称

