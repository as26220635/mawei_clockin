create definer = root@localhost view v_process_start as
select `sps`.`ID`     AS `ID`,
       `sps`.`SPD_ID` AS `SPD_ID`,
       `sps`.`SR_ID`  AS `SR_ID`,
       `sr`.`SR_NAME` AS `SR_NAME`,
       `sr`.`SR_CODE` AS `SR_CODE`
from (`mawei_clockin`.`sys_process_start` `sps`
         left join `mawei_clockin`.`sys_role` `sr` on ((`sr`.`ID` = `sps`.`SR_ID`)));

-- comment on column v_process_start.SPD_ID not supported: 流程定义表ID

-- comment on column v_process_start.SR_ID not supported: 流程启动角色

-- comment on column v_process_start.SR_NAME not supported: 角色名

-- comment on column v_process_start.SR_CODE not supported: 角色编码

