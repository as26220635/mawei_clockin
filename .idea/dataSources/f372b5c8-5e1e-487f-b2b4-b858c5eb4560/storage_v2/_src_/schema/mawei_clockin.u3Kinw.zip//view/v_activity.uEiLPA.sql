create definer = root@localhost view v_activity as
select `ba`.`ID`                                     AS `ID`,
       `ba`.`BA_TITLE`                               AS `BA_TITLE`,
       `ba`.`BA_ENTRY_TIME`                          AS `BA_ENTRY_TIME`,
       `ba`.`BA_UPDATE_TIME`                         AS `BA_UPDATE_TIME`,
       `ba`.`IS_STATUS`                              AS `IS_STATUS`,
       `sai`.`SAI_NAME`                              AS `SAI_NAME`,
       `sf`.`ID`                                     AS `SF_ID`,
       concat(`sf`.`SF_PATH`, '@@@', `sf`.`SF_NAME`) AS `IMG_PATH`
from ((`mawei_clockin`.`bus_activity` `ba` left join `mawei_clockin`.`sys_account_info` `sai` on ((convert(`sai`.`SO_ID` using utf8mb4) = `ba`.`SO_ID`)))
         left join `mawei_clockin`.`sys_file` `sf` on (((`sf`.`SF_TABLE_NAME` = 'BUS_ACTIVITY') and
                                                        (convert(`sf`.`SF_TABLE_ID` using utf8mb4) = `ba`.`ID`))));

-- comment on column v_activity.BA_TITLE not supported: 活动标题

-- comment on column v_activity.BA_ENTRY_TIME not supported: 录入时间

-- comment on column v_activity.BA_UPDATE_TIME not supported: 更新时间

-- comment on column v_activity.IS_STATUS not supported: 状态 $SYS_ON_OFF$

-- comment on column v_activity.SAI_NAME not supported: 账号名称

