create definer = root@localhost view v_log_value_record_detail as
select `svr`.`ID`             AS `ID`,
       `svr`.`SO_ID`          AS `SO_ID`,
       `svr`.`SVR_TABLE_NAME` AS `SVR_TABLE_NAME`,
       `svr`.`SVR_TABLE_ID`   AS `SVR_TABLE_ID`,
       `svr`.`SVR_OLD_VALUE`  AS `SVR_OLD_VALUE`,
       `svr`.`SVR_NEW_VALUE`  AS `SVR_NEW_VALUE`,
       `svr`.`SVR_ENTRY_TIME` AS `SVR_ENTRY_TIME`,
       `svr`.`SVR_TYPE`       AS `SVR_TYPE`,
       `sai`.`SAI_NAME`       AS `SAI_NAME`
from (`mawei_clockin`.`sys_value_record` `svr`
         left join `mawei_clockin`.`sys_account_info` `sai` on ((`sai`.`SO_ID` = `svr`.`SO_ID`)));

-- comment on column v_log_value_record_detail.SO_ID not supported: 操作人ID

-- comment on column v_log_value_record_detail.SVR_TABLE_NAME not supported: 记录表名

-- comment on column v_log_value_record_detail.SVR_TABLE_ID not supported: 记录表ID

-- comment on column v_log_value_record_detail.SVR_OLD_VALUE not supported: 旧值

-- comment on column v_log_value_record_detail.SVR_NEW_VALUE not supported: 新值

-- comment on column v_log_value_record_detail.SVR_ENTRY_TIME not supported: 录入时间

-- comment on column v_log_value_record_detail.SVR_TYPE not supported: 类型，1插入2更新3删除

-- comment on column v_log_value_record_detail.SAI_NAME not supported: 账号名称

