create definer = root@localhost view v_configure_search as
select `scs`.`ID`              AS `ID`,
       `scs`.`SC_ID`           AS `SC_ID`,
       `scs`.`SCS_NAME`        AS `SCS_NAME`,
       `scs`.`SCS_FIELD`       AS `SCS_FIELD`,
       `scs`.`SCS_SDT_CODE`    AS `SCS_SDT_CODE`,
       `scs`.`SCS_METHOD_TYPE` AS `SCS_METHOD_TYPE`,
       `scs`.`SCS_TYPE`        AS `SCS_TYPE`,
       `scs`.`SCC_IS_VISIBLE`  AS `SCC_IS_VISIBLE`,
       `scs`.`SCS_ORDER`       AS `SCS_ORDER`,
       `scs`.`SCS_REMARK`      AS `SCS_REMARK`
from `mawei_clockin`.`sys_configure_search` `scs`;

-- comment on column v_configure_search.SCS_NAME not supported: 名称

-- comment on column v_configure_search.SCS_FIELD not supported: 查询字段

-- comment on column v_configure_search.SCS_SDT_CODE not supported: 字典CODE

-- comment on column v_configure_search.SCS_METHOD_TYPE not supported: 查询条件

-- comment on column v_configure_search.SCS_TYPE not supported: 搜索类型

-- comment on column v_configure_search.SCC_IS_VISIBLE not supported: 是否要显示到界面上

-- comment on column v_configure_search.SCS_ORDER not supported: 排序

-- comment on column v_configure_search.SCS_REMARK not supported: 备注

