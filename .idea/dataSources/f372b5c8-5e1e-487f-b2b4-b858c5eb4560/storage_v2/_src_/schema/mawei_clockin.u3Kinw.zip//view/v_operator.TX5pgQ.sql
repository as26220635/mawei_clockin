create definer = root@localhost view v_operator as
select `so`.`ID`            AS `ID`,
       `so`.`IS_STATUS`     AS `IS_STATUS`,
       `sai`.`SAI_NAME`     AS `SAI_NAME`,
       `sai`.`SAI_PHONE`    AS `SAI_PHONE`,
       `sai`.`SAI_EMAIL`    AS `SAI_EMAIL`,
       `sos`.`SOS_USERNAME` AS `SOS_USERNAME`,
       `sai`.`SAI_TYPE`     AS `SAI_TYPE`,
       `tdi`.`SDI_NAME`     AS `SAI_TYPE_NAME`
from (((`mawei_clockin`.`sys_operator` `so` join `mawei_clockin`.`sys_account_info` `sai` on ((`sai`.`SO_ID` = `so`.`ID`))) left join (select `sos`.`SO_ID`                                             AS `SO_ID`,
                                                                                                                                              group_concat(distinct `sos`.`SOS_USERNAME` separator ',') AS `SOS_USERNAME`
                                                                                                                                       from `mawei_clockin`.`sys_operator_sub` `sos`
                                                                                                                                       group by `sos`.`SO_ID`) `sos` on ((`sos`.`SO_ID` = `so`.`ID`)))
         left join `mawei_clockin`.`sys_dict_info` `tdi`
                   on (((`tdi`.`SDT_CODE` = 'SYS_ROLE_TYPE') and (`tdi`.`SDI_CODE` = `sai`.`SAI_TYPE`))));

-- comment on column v_operator.IS_STATUS not supported: 状态 $SYS_ON_OFF$

-- comment on column v_operator.SAI_NAME not supported: 账号名称

-- comment on column v_operator.SAI_PHONE not supported: 手机

-- comment on column v_operator.SAI_EMAIL not supported: 邮箱

-- comment on column v_operator.SAI_TYPE not supported: 用户类型$SYS_ROLE_TYPE$

-- comment on column v_operator.SAI_TYPE_NAME not supported: 字典名称

