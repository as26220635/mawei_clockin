create definer = root@localhost view v_log_use as
select `sl`.`ID`           AS `ID`,
       `sl`.`SO_ID`        AS `SO_ID`,
       `sl`.`SL_NAME`      AS `SL_NAME`,
       `sl`.`SL_EVENT`     AS `SL_EVENT`,
       `sl`.`SL_IP`        AS `SL_IP`,
       `sl`.`SL_RESULT`    AS `SL_RESULT`,
       `sl`.`SL_ENTERTIME` AS `SL_ENTERTIME`,
       `sl`.`SL_ENTERTIME` AS `SL_ENDTIME`,
       `slt`.`SLT_CONTENT` AS `SLT_CONTENT`,
       `sai`.`SAI_NAME`    AS `SAI_NAME`
from ((`mawei_clockin`.`sys_log` `sl` left join `mawei_clockin`.`sys_log_text` `slt` on ((`slt`.`SL_ID` = `sl`.`ID`)))
         left join `mawei_clockin`.`sys_account_info` `sai` on ((`sai`.`SO_ID` = `sl`.`SO_ID`)))
where (`sl`.`SL_TYPE` = 2);

-- comment on column v_log_use.SO_ID not supported: 用户表主键

-- comment on column v_log_use.SL_NAME not supported: 日志标题

-- comment on column v_log_use.SL_EVENT not supported: 操作事件

-- comment on column v_log_use.SL_IP not supported: 操作IP

-- comment on column v_log_use.SL_RESULT not supported: 日志操作结果 0 失败 1成功

-- comment on column v_log_use.SL_ENTERTIME not supported: 录入时间

-- comment on column v_log_use.SL_ENDTIME not supported: 录入时间

-- comment on column v_log_use.SLT_CONTENT not supported: 日志内容

-- comment on column v_log_use.SAI_NAME not supported: 账号名称

