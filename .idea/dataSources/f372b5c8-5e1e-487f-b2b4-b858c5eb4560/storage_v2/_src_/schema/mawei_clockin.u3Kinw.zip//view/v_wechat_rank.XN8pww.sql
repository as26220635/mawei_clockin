create definer = root@localhost view v_wechat_rank as
select `bwr`.`ID`                AS `ID`,
       `bwr`.`BW_ID`             AS `BW_ID`,
       `bwr`.`BW_USERNAME`       AS `BW_USERNAME`,
       `bwr`.`BW_AVATAR`         AS `BW_AVATAR`,
       `bwr`.`BWR_RANK`          AS `BWR_RANK`,
       `bwr`.`BWR_LAST_TIME`     AS `BWR_LAST_TIME`,
       `bwr`.`BWR_CLOCKIN_COUNT` AS `BWR_CLOCKIN_COUNT`,
       `bwr`.`BWP_NUMBER`        AS `BWP_NUMBER`,
       `bwr`.`BWR_LIGHT_ICON`    AS `BWR_LIGHT_ICON`
from `mawei_clockin`.`bus_wechat_rank` `bwr`;

-- comment on column v_wechat_rank.BW_USERNAME not supported: 用户名

-- comment on column v_wechat_rank.BW_AVATAR not supported: 用户头像

-- comment on column v_wechat_rank.BWR_RANK not supported: 排名

-- comment on column v_wechat_rank.BWR_LAST_TIME not supported: 最后打卡时间

-- comment on column v_wechat_rank.BWR_CLOCKIN_COUNT not supported: 打卡数

-- comment on column v_wechat_rank.BWP_NUMBER not supported: 点赞数

-- comment on column v_wechat_rank.BWR_LIGHT_ICON not supported: 点亮的图标

