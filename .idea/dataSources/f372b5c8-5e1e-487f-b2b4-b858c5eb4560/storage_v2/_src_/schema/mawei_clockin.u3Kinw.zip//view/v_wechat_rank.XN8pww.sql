create view v_wechat_rank as
select `bw`.`ID`                     AS `ID`,
       `bw`.`BW_AVATAR`              AS `BW_AVATAR`,
       `bw`.`BW_USERNAME`            AS `BW_USERNAME`,
       ifnull(`bwr`.`BWR_RANK`, '无') AS `BWR_RANK`,
       `bwr`.`BWR_LAST_TIME`         AS `BWR_LAST_TIME`,
       `bwr`.`BWR_CLOCKIN_COUNT`     AS `BWR_CLOCKIN_COUNT`,
       ifnull(`bwp`.`BWP_NUMBER`, 0) AS `BWP_NUMBER`
from ((`mawei_clockin`.`bus_wechat` `bw` left join `mawei_clockin`.`bus_wechat_praise` `bwp` on ((`bwp`.`BW_ID` = `bw`.`ID`)))
         left join `mawei_clockin`.`bus_wechat_rank` `bwr` on ((`bwr`.`BW_ID` = `bw`.`ID`)))
order by ifnull(cast(`bwr`.`BWR_RANK` as signed), 999999);

-- comment on column v_wechat_rank.BW_AVATAR not supported: 头像地址

-- comment on column v_wechat_rank.BW_USERNAME not supported: 用户名

-- comment on column v_wechat_rank.BWR_LAST_TIME not supported: 最后打卡时间

-- comment on column v_wechat_rank.BWR_CLOCKIN_COUNT not supported: 打卡数

