create definer = root@localhost view v_format as
select `sf`.`ID`            AS `ID`,
       `sf`.`SF_NAME`       AS `SF_NAME`,
       `sf`.`SF_CODE`       AS `SF_CODE`,
       `sf`.`SF_YEAR`       AS `SF_YEAR`,
       `sf`.`SF_ENTRY_TIME` AS `SF_ENTRY_TIME`
from `mawei_clockin`.`sys_format` `sf`;

-- comment on column v_format.SF_NAME not supported: 名称

-- comment on column v_format.SF_CODE not supported: 唯一标识

-- comment on column v_format.SF_YEAR not supported: 配置年度

-- comment on column v_format.SF_ENTRY_TIME not supported: 添加时间

