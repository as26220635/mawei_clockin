create definer = root@localhost view v_process_definition as
select `spd`.`ID`                   AS `ID`,
       `spd`.`SO_ID`                AS `SO_ID`,
       `spd`.`SR_ID`                AS `SR_ID`,
       `spd`.`BUS_PROCESS`          AS `BUS_PROCESS`,
       `spd`.`BUS_PROCESS2`         AS `BUS_PROCESS2`,
       `spd`.`SPD_NAME`             AS `SPD_NAME`,
       `spd`.`SPD_VERSION`          AS `SPD_VERSION`,
       `spd`.`SPD_UPDATE_TABLE`     AS `SPD_UPDATE_TABLE`,
       `spd`.`SPD_UPDATE_NAME`      AS `SPD_UPDATE_NAME`,
       `spd`.`SPD_COLLEGE_FIELD`    AS `SPD_COLLEGE_FIELD`,
       `spd`.`SPD_DEPARTMENT_FIELD` AS `SPD_DEPARTMENT_FIELD`,
       `spd`.`SPD_CLASS_FIELD`      AS `SPD_CLASS_FIELD`,
       `spd`.`SPD_DESCRIBE`         AS `SPD_DESCRIBE`,
       `spd`.`SDP_ENTRY_TIME`       AS `SDP_ENTRY_TIME`,
       `spd`.`IS_STATUS`            AS `IS_STATUS`,
       `spd`.`IS_MULTISTAGE_BACK`   AS `IS_MULTISTAGE_BACK`,
       `spd`.`IS_TIME_CONTROL`      AS `IS_TIME_CONTROL`,
       (case
            when (`spd`.`IS_TIME_CONTROL` = 1) then concat(`sptc`.`SPTC_START_TIME`, '  -  ', `sptc`.`SPTC_END_TIME`)
            else '' end)            AS `SPTC_TIME`
from (`mawei_clockin`.`sys_process_definition` `spd`
         left join `mawei_clockin`.`sys_process_time_control` `sptc`
                   on (((`sptc`.`SPD_ID` = convert(`spd`.`ID` using utf8mb4)) and (`sptc`.`IS_STATUS` = 1))));

-- comment on column v_process_definition.SO_ID not supported: 创建人@SYS_ACCOUNT_INFO,SO_ID,SAI_NAME@

-- comment on column v_process_definition.SR_ID not supported: 查看全部记录角色

-- comment on column v_process_definition.BUS_PROCESS not supported: 流程大类$SYS_PROCESS_TYPE$

-- comment on column v_process_definition.BUS_PROCESS2 not supported: 流程小类$SYS_PROCESS_TYPE$

-- comment on column v_process_definition.SPD_NAME not supported: 流程名称

-- comment on column v_process_definition.SPD_VERSION not supported: 流程版本

-- comment on column v_process_definition.SPD_UPDATE_TABLE not supported: 流程更新表名

-- comment on column v_process_definition.SPD_UPDATE_NAME not supported: 流程更新表名称字段

-- comment on column v_process_definition.SPD_COLLEGE_FIELD not supported: 院系ID字段

-- comment on column v_process_definition.SPD_DEPARTMENT_FIELD not supported: 系部ID字段

-- comment on column v_process_definition.SPD_CLASS_FIELD not supported: 班级ID字段

-- comment on column v_process_definition.SPD_DESCRIBE not supported: 流程描述

-- comment on column v_process_definition.SDP_ENTRY_TIME not supported: 添加时间

-- comment on column v_process_definition.IS_STATUS not supported: 是否启用$SYS_YES_NO$

-- comment on column v_process_definition.IS_MULTISTAGE_BACK not supported: 是否允许多级回退$SYS_YES_NO$

-- comment on column v_process_definition.IS_TIME_CONTROL not supported: 是否开启时间控制$SYS_YES_NO$

