create definer = root@localhost view v_dict_type as
select `sdt`.`ID`        AS `ID`,
       `sdt`.`SDT_NAME`  AS `SDT_NAME`,
       `sdt`.`SDT_CODE`  AS `SDT_CODE`,
       `sdt`.`IS_STATUS` AS `IS_STATUS`
from `mawei_clockin`.`sys_dict_type` `sdt`;

-- comment on column v_dict_type.SDT_NAME not supported: 字典名称

-- comment on column v_dict_type.SDT_CODE not supported: 字典编码

-- comment on column v_dict_type.IS_STATUS not supported: 状态:0停用1启用

